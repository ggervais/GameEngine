package com.ggervais.gameengine.scene;

import java.awt.event.KeyEvent;

import net.java.games.input.Component.Identifier.Key;

import com.ggervais.gameengine.input.EventSource;
import com.ggervais.gameengine.input.InputPoller;
import com.ggervais.gameengine.input.KeyboardState;
import com.ggervais.gameengine.input.MouseState;
import com.ggervais.gameengine.math.Point3D;
import com.ggervais.gameengine.math.Vector3D;

public class FreeFlyCamera extends Camera {

	private static final float SPEED = 0.1f;
	private static final float ONE_RADIAN = 0.01745f;
	private static final float MIN_PHI = (float) (-Math.PI / 2 + ONE_RADIAN);
	private static final float MAX_PHI = (float) (Math.PI / 2 - ONE_RADIAN);
	
	private MouseState oldMouseState;
	
	private float theta;
	private float phi;
	
	Vector3D up;
	Vector3D right;
	
	public FreeFlyCamera(Point3D position, Vector3D direction, Vector3D up) {
		super(position, direction, up);
		this.oldMouseState = null;
		this.theta = (float) Math.toRadians(-90);
		this.phi = 0;
		this.up = new Vector3D(0, 1, 0);
		this.right = new Vector3D(1, 0, 0);
	}
	
	public FreeFlyCamera() {
		super();
		this.oldMouseState = null;
		this.theta = (float) Math.toRadians(-90);
		this.phi = 0;
		this.up = new Vector3D(0, 1, 0);
		this.right = new Vector3D(1, 0, 0);
	}
	
	private void clampPhi() {
		if (this.phi < MIN_PHI) {
			this.phi = MIN_PHI;
		}
		
		if (this.phi > MAX_PHI) {
			this.phi = MAX_PHI;
		}
	}
	
	@Override
	public void update(InputPoller inputPoller) {
		
		if (inputPoller.isKeyDown(Key.W)) {
			this.position.x(this.position.x() + this.direction.x() * SPEED);
			this.position.y(this.position.y() + this.direction.y() * SPEED);
			this.position.z(this.position.z() + this.direction.z() * SPEED);
		}
		if (inputPoller.isKeyDown(Key.A)) {
			this.position.x(this.position.x() - this.right.x() * SPEED);
			this.position.z(this.position.z() - this.right.z() * SPEED);
		}
		if (inputPoller.isKeyDown(Key.S)) {
			this.position.x(this.position.x() - this.direction.x() * SPEED);
			this.position.y(this.position.y() - this.direction.y() * SPEED);
			this.position.z(this.position.z() - this.direction.z() * SPEED);
		}
		if (inputPoller.isKeyDown(Key.D)) {
			this.position.x(this.position.x() + this.right.x() * SPEED);
			this.position.z(this.position.z() + this.right.z() * SPEED);
		}
		
		float diffX = inputPoller.getMouseMovementX();
		float diffY = inputPoller.getMouseMovementY();
		
		this.theta += diffX * 0.005;
		this.phi -= diffY * 0.005;
		
		clampPhi();
		
		this.direction.x((float) Math.cos(this.theta) * (float) Math.cos(this.phi));
		this.direction.y((float) Math.sin(this.phi));
		this.direction.z((float) Math.sin(this.theta) * (float) Math.cos(this.phi));
		this.direction.normalize();
		
		Vector3D cross = Vector3D.crossProduct(this.direction, this.up).normalized();
		this.right.x(cross.x());
		this.right.y(cross.y());
		this.right.z(cross.z());
		
		//System.out.println("Position -> " + this.position + ", Direction -> " + this.direction + ", Right -> " + this.right + ", LookAt -> " + getLookAt());
		
	}

}
