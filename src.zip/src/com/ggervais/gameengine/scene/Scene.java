package com.ggervais.gameengine.scene;

import java.util.List;
import java.util.ArrayList;
import java.util.Observable;

import com.ggervais.gameengine.geometry.Arrow;
import com.ggervais.gameengine.geometry.Cube;
import com.ggervais.gameengine.geometry.Sphere;
import com.ggervais.gameengine.input.InputPoller;
import com.ggervais.gameengine.input.KeyboardState;
import com.ggervais.gameengine.input.MouseState;
import com.ggervais.gameengine.math.Point3D;
import com.ggervais.gameengine.math.Vector3D;

public class Scene extends Observable {

	private Camera camera;
	private List<DisplayableEntity> entities;
	
	public Scene() {
		this.entities = new ArrayList<DisplayableEntity>();
		this.camera = new FreeFlyCamera();
	}
	
	public void init() {
		
		DisplayableEntity cube = new DisplayableEntity(new Cube());
		cube.setPosition(new Point3D(0, 0, 0));
		//cube.setDirection(new Vector3D(1, 0, 0));
		
		DisplayableEntity arrow = new DisplayableEntity(new Arrow());
		arrow.setDirection(new Vector3D(1, 0, 0));
		
		DisplayableEntity sphere = new DisplayableEntity(new Sphere());
		sphere.setDirection(new Vector3D(1, 1, 1));
		
		this.entities.add(arrow);
		//this.entities.add(sphere);
	}
	
	public List<DisplayableEntity> getEntities() {
		return this.entities;
	}
	
	public void update(KeyboardState keyboardState, MouseState mouseState, InputPoller inputPoller) {
		this.camera.update(inputPoller);
		
		for(DisplayableEntity entity : this.entities) {
			//entity.setDirection(this.camera.getDirection());
		}
	}
	
	public void render() {
		setChanged();
		notifyObservers();
	}

	public void setCamera(Camera camera) {
		this.camera = camera;
	}

	public Camera getCamera() {
		return camera;
	}
}
