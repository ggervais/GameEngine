package com.ggervais.gameengine.scene;

import com.ggervais.gameengine.geometry.Model;
import com.ggervais.gameengine.math.Point3D;
import com.ggervais.gameengine.math.Vector3D;

public class DisplayableEntity {
	
	private Point3D position;
	private Vector3D scale;
	private Vector3D direction;
	
	private Model model;
	
	public DisplayableEntity(Model model) {
		this.model = model;
		this.setPosition(Point3D.zero());
		this.setScale(new Vector3D(1, 1, 1));
		this.setDirection(new Vector3D(1, 0, 0));
	}
	
	private void setModel(Model model) {
		this.model = model;
	}
	
	public Model getModel() {
		return this.model;
	}

	public void setPosition(Point3D position) {
		this.position = position;
	}

	public Point3D getPosition() {
		return position;
	}

	public void setScale(Vector3D scale) {
		this.scale = scale;
	}

	public Vector3D getScale() {
		return scale;
	}

	public void setDirection(Vector3D direction) {
		this.direction = direction;
	}

	public Vector3D getDirection() {
		return direction;
	}
}
