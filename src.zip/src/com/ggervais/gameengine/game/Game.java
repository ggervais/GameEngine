package com.ggervais.gameengine.game;

import java.awt.Component;

import javax.swing.JFrame;

import com.ggervais.gameengine.input.InputListener;
import com.ggervais.gameengine.input.InputPoller;
import com.ggervais.gameengine.input.KeyboardState;
import com.ggervais.gameengine.input.MouseState;
import com.ggervais.gameengine.render.SceneRenderer;
import com.ggervais.gameengine.render.opengl.GLRendererFactory;
import com.ggervais.gameengine.scene.Scene;

public class Game {
	private Scene scene;
	private SceneRenderer renderer;
	private InputListener inputListener;
	private InputPoller inputPoller;
	private JFrame frame;
	private Fullscreen fullscreen;
	private static final int QUANTUM = (int) (1000.0f / 60.0f); // About 16 or 17 milliseconds.
	private static int WIDTH = 640;
	private static int HEIGHT = 480;
	
	public Game() {
		init();
	}
	
	public int getWidth() {
		return WIDTH;
	}
	
	public int getHeight() {
		return HEIGHT;
	}
	
	private void initGUI() {
		this.frame = new JFrame("Guillaume Gervais' Game Engine");
		this.frame.setSize(WIDTH, HEIGHT);
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.frame.setUndecorated(true);
		this.frame.setFocusable(true);
		
		//this.frame.setSize(this.fullscreen.getWidth(), this.fullscreen.getHeight());
		//this.fullscreen.init(this.frame);
		
		Component canvas = this.renderer.getCanvas();
		canvas.addKeyListener(this.inputListener);
		//canvas.addMouseListener(this.inputListener);
		//canvas.addMouseMotionListener(this.inputListener);
		this.inputPoller = new InputPoller();
		this.inputPoller.init();
		
		
		this.frame.add(canvas);
		
	}
	
	public void init() {
		this.scene = new Scene();
		this.renderer = new GLRendererFactory().buildRenderer(this.scene);
		this.inputListener = new InputListener(this);
		this.scene.init();
		this.fullscreen = new Fullscreen();
		
		initGUI();
	}
	
	public void start() {
		this.frame.setVisible(true);
		this.renderer.getCanvas().requestFocus();
		mainLoop();
	}
	
	public void update() {
		KeyboardState keyboardState = this.inputListener.getCurrentKeyboardState();
		MouseState mouseState = this.inputListener.getCurrentMouseState();
		
		this.inputPoller.update();
		this.scene.update(keyboardState, mouseState, this.inputPoller);
	}
	
	private void mainLoop() {
		long currentTime = System.currentTimeMillis();
		long previousTime = currentTime;
		
		boolean done = false;
		while (!done) {
			currentTime = System.currentTimeMillis();
			long timeDifference = currentTime - previousTime;
			if (timeDifference > QUANTUM) {
				update();
				this.scene.render();
				previousTime = currentTime;
			} else {
				long sleepTime = QUANTUM - timeDifference;
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException ie) {
					
				}
			}
		}
	}
	
	public void setScene(Scene scene) {
		this.scene = scene;
	}

	public Scene getScene() {
		return scene;
	}
}
