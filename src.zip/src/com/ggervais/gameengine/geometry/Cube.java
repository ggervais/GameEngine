package com.ggervais.gameengine.geometry;

import java.awt.Color;

import com.ggervais.gameengine.geometry.primitives.Vertex;
import com.ggervais.gameengine.math.Point3D;

public class Cube extends Model {
	
	public Cube() {
		super(4);
		create();
	}
	
	@Override
	public void create() {
		
		this.vertexBuffer.addVertex(new Vertex(new Point3D(0.5f, 0.5f, 0.5f), Color.RED, 0, 0));
		this.vertexBuffer.addVertex(new Vertex(new Point3D(-0.5f, 0.5f, 0.5f), Color.RED, 0, 0));
		this.vertexBuffer.addVertex(new Vertex(new Point3D(-0.5f, -0.5f, 0.5f), Color.RED, 0, 0));
		this.vertexBuffer.addVertex(new Vertex(new Point3D(0.5f, -0.5f, 0.5f), Color.RED, 0, 0));
		
		this.vertexBuffer.addVertex(new Vertex(new Point3D(0.5f, 0.5f, -0.5f), Color.RED, 0, 0));
		this.vertexBuffer.addVertex(new Vertex(new Point3D(-0.5f, 0.5f, -0.5f), Color.RED, 0, 0));
		this.vertexBuffer.addVertex(new Vertex(new Point3D(-0.5f, -0.5f, -0.5f), Color.RED, 0, 0));
		this.vertexBuffer.addVertex(new Vertex(new Point3D(0.5f, -0.5f, -0.5f), Color.RED, 0, 0));
		
		// 1st
		this.indexBuffer.addIndex(0);
		this.indexBuffer.addIndex(1);
		this.indexBuffer.addIndex(2);
		this.indexBuffer.addIndex(3);
		
		// 2nd
		this.indexBuffer.addIndex(0);
		this.indexBuffer.addIndex(4);
		this.indexBuffer.addIndex(5);
		this.indexBuffer.addIndex(1);
		
		// 3rd
		this.indexBuffer.addIndex(2);
		this.indexBuffer.addIndex(6);
		this.indexBuffer.addIndex(7);
		this.indexBuffer.addIndex(3);
		
		// 4th
		this.indexBuffer.addIndex(7);
		this.indexBuffer.addIndex(6);
		this.indexBuffer.addIndex(5);
		this.indexBuffer.addIndex(4);
		
		// 5th
		this.indexBuffer.addIndex(3);
		this.indexBuffer.addIndex(7);
		this.indexBuffer.addIndex(4);
		this.indexBuffer.addIndex(0);
		
		// 6th
		this.indexBuffer.addIndex(1);
		this.indexBuffer.addIndex(5);
		this.indexBuffer.addIndex(6);
		this.indexBuffer.addIndex(2);
	}

}
