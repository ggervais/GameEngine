package com.ggervais.gameengine.geometry;

import com.ggervais.gameengine.geometry.primitives.IndexBuffer;
import com.ggervais.gameengine.geometry.primitives.VertexBuffer;

public abstract class Model {
	
	private static final int DEFAULT_NB_VERTICES_PER_FACE = 3;
	
	protected VertexBuffer vertexBuffer;
	protected IndexBuffer indexBuffer;
	protected int nbVerticesPerFace;
	
	public Model() {
		this(DEFAULT_NB_VERTICES_PER_FACE); // Defaults to triangle.
	}
	
	public Model(int nbVerticesPerFace) {
		this.vertexBuffer = new VertexBuffer();
		this.indexBuffer = new IndexBuffer();
		this.nbVerticesPerFace = nbVerticesPerFace;
	}
	
	public VertexBuffer getVertexBuffer() {
		return this.vertexBuffer;
	}
	
	public IndexBuffer getIndexBuffer() {
		return this.indexBuffer;
	}
	
	public int getNbVerticesPerFace() {
		return this.nbVerticesPerFace;
	}
	
	public float getScale() {
		return 1.0f;
	}
	
	public abstract void create();
}
