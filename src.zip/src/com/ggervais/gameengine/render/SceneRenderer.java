package com.ggervais.gameengine.render;

import java.awt.Component;
import java.util.Observable;
import java.util.Observer;

import com.ggervais.gameengine.scene.Scene;

// Render the scene onto a "canvas" (in our case, a Component).
public abstract class SceneRenderer implements Observer {
	
	protected Scene scene;
	protected Component canvas;
	
	public SceneRenderer() {
		
	}
	
	public SceneRenderer(Scene scene, Component canvas) {
		this.scene = scene;
		this.canvas = canvas;
		this.scene.addObserver(this);
	}
	
	public abstract void update(Observable source, Object args);

	public void setScene(Scene scene) {
		this.scene = scene;
	}

	public Scene getScene() {
		return scene;
	}
	
	public void setCanvas(Component canvas) {
		this.canvas = canvas;
	}
	
	public Component getCanvas() {
		return this.canvas;
	}
}
