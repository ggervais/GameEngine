package com.ggervais.gameengine.render;

import java.awt.Component;

public interface DisplayFactory {

	public Component createDisplay();
}
