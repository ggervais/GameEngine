package com.ggervais.gameengine.render.opengl;

import java.awt.Color;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;

import com.ggervais.gameengine.geometry.Model;
import com.ggervais.gameengine.geometry.primitives.Vertex;
import com.ggervais.gameengine.math.MathUtils;
import com.ggervais.gameengine.math.Matrix4x4;
import com.ggervais.gameengine.math.Point3D;
import com.ggervais.gameengine.math.RotationMatrix;
import com.ggervais.gameengine.math.ScaleMatrix;
import com.ggervais.gameengine.math.TranslationMatrix;
import com.ggervais.gameengine.math.Vector3D;

public class OpenGLUtils {

	public static void drawModel(GL2 gl, Model model, Point3D position, Vector3D scale, Vector3D direction) {
		
		int nbVerticesPerFace = model.getNbVerticesPerFace();
		int glPrimitiveType = GL2.GL_TRIANGLES; // Defaults to triangles.
		
		switch(nbVerticesPerFace) {
			case 1:
				glPrimitiveType = GL2.GL_POINTS;
				break;
			case 2:
				glPrimitiveType = GL2.GL_LINES;
				break;
			case 3:
				glPrimitiveType = GL2.GL_TRIANGLES;
				break;
			case 4:
				glPrimitiveType = GL2.GL_QUADS;
				break;
		}
		
		gl.glPushMatrix();
		
		float angle = (float) Math.toDegrees(MathUtils.convertDirectionToAngle(direction));
		Vector3D axis = MathUtils.convertDirectionToAxis(direction);
		
		TranslationMatrix tm = new TranslationMatrix(position.x(), position.y(), position.z());
		gl.glMultMatrixf(tm.convertToOpenGLFormat(), 0);

		Matrix4x4 rm = RotationMatrix.createFromAxisAndAngle(axis, angle);
		gl.glMultMatrixf(rm.convertToOpenGLFormat(), 0);
		
		ScaleMatrix sm = new ScaleMatrix(scale.x(), scale.y(), scale.z());
		gl.glMultMatrixf(sm.convertToOpenGLFormat(), 0);
		
		//gl.glRotatef(angle, axis.x(), axis.y(), axis.z());
		//gl.glScalef(scale.x(), scale.y(), scale.z());
		gl.glBegin(glPrimitiveType);
			for(int i = 0; i < model.getIndexBuffer().size(); i++) {
				int index = model.getIndexBuffer().getIndex(i);
				Vertex vertex = model.getVertexBuffer().getVertex(index);
				
				Point3D vertexPosition = vertex.getPosition();
				Color vertexColor = vertex.getColor();
				
				float r = vertexColor.getRed();
				float g = vertexColor.getGreen();
				float b = vertexColor.getBlue();
				
				gl.glColor3f(r, g, b);
				gl.glVertex3f(vertexPosition.x(), vertexPosition.y(), vertexPosition.z());
			}
		gl.glEnd();
		gl.glPopMatrix();
	}
	
	public static void drawBaseAxis(GL2 gl, Point3D position, float scale) {
		gl.glPushMatrix();
		
		gl.glTranslatef(position.x(), position.y(), position.z());
		gl.glScalef(scale, scale, scale);
		gl.glBegin(GL.GL_LINES);
        	// X axis;
	    	gl.glColor3f(1f, 0f, 0f);
	        gl.glVertex3f(0f, 0f, 0f);
	        gl.glVertex3f(1f, 0f, 0f);
	        
	        // Y axis;
	    	gl.glColor3f(0f, 1f, 0f);
	        gl.glVertex3f(0f, 0f, 0f);
	        gl.glVertex3f(0f, 1f, 0f);
	        
	        // Z axis;
	    	gl.glColor3f(0f, 0f, 1f);
	        gl.glVertex3f(0f, 0f, 0f);
	        gl.glVertex3f(0f, 0f, 1f);
        gl.glEnd();
        
        gl.glPopMatrix();
	}
}
