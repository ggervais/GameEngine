package com.ggervais.gameengine.render.opengl;

import java.util.Observable;
import java.util.Observer;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GL2ES1;
import javax.media.opengl.GL4;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.awt.GLJPanel;
import javax.media.opengl.fixedfunc.GLLightingFunc;
import javax.media.opengl.fixedfunc.GLMatrixFunc;
import javax.media.opengl.glu.GLU;

import com.ggervais.gameengine.geometry.Cube;
import com.ggervais.gameengine.geometry.Marker;
import com.ggervais.gameengine.geometry.Model;
import com.ggervais.gameengine.geometry.Sphere;
import com.ggervais.gameengine.math.Point3D;
import com.ggervais.gameengine.math.Vector3D;
import com.ggervais.gameengine.render.SceneRenderer;
import com.ggervais.gameengine.scene.Camera;
import com.ggervais.gameengine.scene.DisplayableEntity;
import com.ggervais.gameengine.scene.Scene;
import com.jogamp.opengl.util.Animator;

public class GLRenderer extends SceneRenderer implements GLEventListener {

	private GLU glu;
	
	public GLRenderer(Scene scene, GLCanvas canvas) {
		super(scene, canvas);
		canvas.addGLEventListener(this);
		this.glu = new GLU();
	}
	
	@Override
	public void display(GLAutoDrawable glDrawable) {
		GL2 gl = glDrawable.getGL().getGL2();
		
		gl.glClear(GL.GL_COLOR_BUFFER_BIT);
        gl.glClear(GL.GL_DEPTH_BUFFER_BIT);
        gl.glClearColor(1, 1, 1, 0);
        
        gl.glMatrixMode(GLMatrixFunc.GL_MODELVIEW);
        gl.glLoadIdentity();

        Camera camera = this.scene.getCamera();
        Point3D cameraPosition = camera.getPosition();
        Point3D cameraLookAt = camera.getLookAt();
        Vector3D cameraUp = camera.getUp();
        
        this.glu.gluLookAt(cameraPosition.x(), cameraPosition.y(), cameraPosition.z(), 
        				   cameraLookAt.x(), cameraLookAt.y(), cameraLookAt.z(),
        				   cameraUp.x(), cameraUp.y(), cameraUp.z());
        
        int i = 0;
        for (DisplayableEntity entity: this.scene.getEntities()) {
        	float scale = 1.0f;
        	OpenGLUtils.drawModel(gl, entity.getModel(), entity.getPosition(), entity.getScale(), entity.getDirection());
        	i++;
        }
        
        gl.glFlush();
	}

	@Override
	public void dispose(GLAutoDrawable glDrawable) {
	}

	@Override
	public void init(GLAutoDrawable glDrawable) {
		GL2 gl = glDrawable.getGL().getGL2();
		gl.glShadeModel(GLLightingFunc.GL_SMOOTH);
        gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        gl.glClearDepth(1.0f);
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glDepthFunc(GL.GL_LEQUAL);
        gl.glHint(GL2ES1.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
        gl.glEnable(GL.GL_CULL_FACE);
        gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL2.GL_FILL);
	}

	@Override
	public void reshape(GLAutoDrawable glDrawable, int x, int y, int width,	int height) {
		GL2 gl = glDrawable.getGL().getGL2();
		
		if (height <= 0) {
			height = 1;
		}
		
		float aspectRatio = (float) width / (float) height;
		
		gl.glMatrixMode(GLMatrixFunc.GL_PROJECTION);
		gl.glLoadIdentity();
		
		this.glu.gluPerspective(45f, aspectRatio, 0.001f, 1000.0f);
		
		gl.glMatrixMode(GLMatrixFunc.GL_MODELVIEW);
		gl.glLoadIdentity();
		
	}

	@Override
	public void update(Observable o, Object arg) {
		this.canvas.repaint();
	}
}
