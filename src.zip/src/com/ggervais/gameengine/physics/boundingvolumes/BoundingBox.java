package com.ggervais.gameengine.physics.boundingvolumes;

import com.ggervais.gameengine.geometry.Model;
import com.ggervais.gameengine.math.Point3D;

public abstract class BoundingBox {
	private Point3D firstCorner;
	private Point3D secondCorner;
	
	public abstract BoundingBox buildFromModel(Model model);
}
