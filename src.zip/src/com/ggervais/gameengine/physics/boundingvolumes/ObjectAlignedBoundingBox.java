package com.ggervais.gameengine.physics.boundingvolumes;

import com.ggervais.gameengine.geometry.Model;

public class ObjectAlignedBoundingBox {

	public static BoundingBox buildFromModel(Model model) {
		return null;
	}
}
