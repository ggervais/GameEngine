package com.ggervais.gameengine.testapp;

import com.ggervais.gameengine.game.Game;

public class Main {

	public static void main(String[] args) {
		
		Game game = new Game();
		game.start();
	}
}
