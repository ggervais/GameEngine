package com.ggervais.gameengine.math;

public class MathUtils {

	public static float convertDirectionToAngle(Vector3D direction) {
		Vector3D standardAxis = new Vector3D(1, 0, 0);
		float dotProduct = standardAxis.dotProduct(direction);
		float normProduct = standardAxis.length() * direction.length();
		return (float) Math.acos(dotProduct / normProduct);
	}
	
	public static Vector3D convertDirectionToAxis(Vector3D direction) {
		Vector3D standardAxis = new Vector3D(1, 0, 0);
		return standardAxis.crossProduct(direction).normalized();
	}
}
