package com.ggervais.gameengine.math;

public class Matrix4x4 {
	private float elements[];
	
	public Matrix4x4() {
		this.elements = new float[16];
		identity();
	}
	
	public Matrix4x4(Matrix4x4 matrix) {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				setElement(i, j, matrix.getElement(i, j));
			}
		}
	}
	
	public void identity() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				int index = i * 4 + j;
				if (i == j) {
					this.elements[index] = 1;
				} else {
					this.elements[index] = 0;
				}
			}
		}
	}
	
	public static Matrix4x4 createIdentity() {
		return new Matrix4x4();
	}
	
	public float getElement(int i, int j) { // i and j go from 1..N, as real matrices do.
		int index = ((i - 1) * 4 + (j - 1));
		return this.elements[index];
	}
	
	public void setElement(int i, int j, float element) { // i and j go from 1..N, as real matrices do.
		int index = ((i - 1) * 4 + (j - 1));
		this.elements[index] = element;
	}
	
	public void mult(Matrix4x4 other) {
		Matrix4x4 temp = Matrix4x4.mult(this, other);
		
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				setElement(i, j, temp.getElement(i, j));
			}
		}
	}
	
	public static Matrix4x4 mult(Matrix4x4 a, Matrix4x4 b) {
		Matrix4x4 result = new Matrix4x4();
		
		// M11
		result.setElement(1, 1, a.getElement(1, 1) * b.getElement(1, 1) + 
						   		a.getElement(1, 2) * b.getElement(2, 1) + 
						   		a.getElement(1, 3) * b.getElement(3, 1) + 
						   		a.getElement(1, 4) * b.getElement(4, 1));
		// M12
		result.setElement(1, 2, a.getElement(1, 1) * b.getElement(1, 2) + 
		   						a.getElement(1, 2) * b.getElement(2, 2) + 
		   						a.getElement(1, 3) * b.getElement(3, 2) + 
		   						a.getElement(1, 4) * b.getElement(4, 2));
		// M13
		result.setElement(1, 3, a.getElement(1, 1) * b.getElement(1, 3) + 
		   						a.getElement(1, 2) * b.getElement(2, 3) + 
		   						a.getElement(1, 3) * b.getElement(3, 3) + 
		   						a.getElement(1, 4) * b.getElement(4, 3));
		// M14
		result.setElement(1, 4, a.getElement(1, 1) * b.getElement(1, 4) + 
		   						a.getElement(1, 2) * b.getElement(2, 4) + 
		   						a.getElement(1, 3) * b.getElement(3, 4) + 
		   						a.getElement(1, 4) * b.getElement(4, 4));
		
		// M21
		result.setElement(2, 1, a.getElement(2, 1) * b.getElement(1, 1) + 
						   		a.getElement(2, 2) * b.getElement(2, 1) + 
						   		a.getElement(2, 3) * b.getElement(3, 1) + 
						   		a.getElement(2, 4) * b.getElement(4, 1));
		// M22
		result.setElement(2, 2, a.getElement(2, 1) * b.getElement(1, 2) + 
		   						a.getElement(2, 2) * b.getElement(2, 2) + 
		   						a.getElement(2, 3) * b.getElement(3, 2) + 
		   						a.getElement(2, 4) * b.getElement(4, 2));
		// M23
		result.setElement(2, 3, a.getElement(2, 1) * b.getElement(1, 3) + 
		   						a.getElement(2, 2) * b.getElement(2, 3) + 
		   						a.getElement(2, 3) * b.getElement(3, 3) + 
		   						a.getElement(2, 4) * b.getElement(4, 3));
		// M24
		result.setElement(2, 4, a.getElement(2, 1) * b.getElement(1, 4) + 
		   						a.getElement(2, 2) * b.getElement(2, 4) + 
		   						a.getElement(2, 3) * b.getElement(3, 4) + 
		   						a.getElement(2, 4) * b.getElement(4, 4));
		
		// M31
		result.setElement(3, 1, a.getElement(3, 1) * b.getElement(1, 1) + 
						   		a.getElement(3, 2) * b.getElement(2, 1) + 
						   		a.getElement(3, 3) * b.getElement(3, 1) + 
						   		a.getElement(3, 4) * b.getElement(4, 1));
		// M32
		result.setElement(3, 2, a.getElement(3, 1) * b.getElement(1, 2) + 
		   						a.getElement(3, 2) * b.getElement(2, 2) + 
		   						a.getElement(3, 3) * b.getElement(3, 2) + 
		   						a.getElement(3, 4) * b.getElement(4, 2));
		// M33
		result.setElement(3, 3, a.getElement(3, 1) * b.getElement(1, 3) + 
		   						a.getElement(3, 2) * b.getElement(2, 3) + 
		   						a.getElement(3, 3) * b.getElement(3, 3) + 
		   						a.getElement(3, 4) * b.getElement(4, 3));
		// M34
		result.setElement(3, 4, a.getElement(3, 1) * b.getElement(1, 4) + 
		   						a.getElement(3, 2) * b.getElement(2, 4) + 
		   						a.getElement(3, 3) * b.getElement(3, 4) + 
		   						a.getElement(3, 4) * b.getElement(4, 4));
		
		// M41
		result.setElement(4, 1, a.getElement(4, 1) * b.getElement(1, 1) + 
						   		a.getElement(4, 2) * b.getElement(2, 1) + 
						   		a.getElement(4, 3) * b.getElement(3, 1) + 
						   		a.getElement(4, 4) * b.getElement(4, 1));
		// M42
		result.setElement(4, 2, a.getElement(4, 1) * b.getElement(1, 2) + 
		   						a.getElement(4, 2) * b.getElement(2, 2) + 
		   						a.getElement(4, 3) * b.getElement(3, 2) + 
		   						a.getElement(4, 4) * b.getElement(4, 2));
		// M43
		result.setElement(4, 3, a.getElement(4, 1) * b.getElement(1, 3) + 
		   						a.getElement(4, 2) * b.getElement(2, 3) + 
		   						a.getElement(4, 3) * b.getElement(3, 3) + 
		   						a.getElement(4, 4) * b.getElement(4, 3));
		// M44
		result.setElement(4, 4, a.getElement(4, 1) * b.getElement(1, 4) + 
		   						a.getElement(4, 2) * b.getElement(2, 4) + 
		   						a.getElement(4, 3) * b.getElement(3, 4) + 
		   						a.getElement(4, 4) * b.getElement(4, 4));
		
		return result;
	}

	public Point3D mult(Point3D point) {
		float x = point.x() * getElement(1, 1) + point.y() * getElement(1, 2) + point.z() * getElement(1,3) + 1 * getElement(1, 4);
		float y = point.x() * getElement(2, 1) + point.y() * getElement(2, 2) + point.z() * getElement(2,3) + 1 * getElement(2, 4);
		float z = point.x() * getElement(3, 1) + point.y() * getElement(3, 2) + point.z() * getElement(3,3) + 1 * getElement(3, 4);
		return new Point3D(x, y, z);
	}
	
	public void mult(float k) {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				setElement(i, j, getElement(i, j) * k);
			}
		}
	}
	
	public static Matrix4x4 mult(Matrix4x4 matrix, float k) {
		Matrix4x4 result = new Matrix4x4();
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				result.setElement(i, j, matrix.getElement(i, j) * k);
			}
		}
		return result;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer("");
		
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				int index = i * 4 + j;
				sb.append(this.elements[index]);
				sb.append(j < 3 ? ", " : "");
			}
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
	public float[] convertToOpenGLFormat() {
		float[] matrixArray = new float[16];
		
		matrixArray[0]  = getElement(1, 1);
		matrixArray[1]  = getElement(2, 1);
		matrixArray[2]  = getElement(3, 1);
		matrixArray[3]  = getElement(4, 1);
		
		matrixArray[4]  = getElement(1, 2);
		matrixArray[5]  = getElement(2, 2);
		matrixArray[6]  = getElement(3, 2);
		matrixArray[7]  = getElement(4, 2);
		
		matrixArray[8]  = getElement(1, 3);
		matrixArray[9]  = getElement(2, 3);
		matrixArray[10] = getElement(3, 3);
		matrixArray[11] = getElement(4, 3);
		
		matrixArray[12] = getElement(1, 4);
		matrixArray[13] = getElement(2, 4);
		matrixArray[14] = getElement(3, 4);
		matrixArray[15] = getElement(4, 4);
		
		return matrixArray;
	}
}
