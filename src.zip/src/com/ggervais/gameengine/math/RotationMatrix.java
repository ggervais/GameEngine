package com.ggervais.gameengine.math;

public class RotationMatrix extends Matrix4x4 {
	
	private float yaw;
	private float pitch;
	private float roll;
	
	public RotationMatrix() {
		super();
		this.yaw = 0;
		this.pitch = 0;
		this.roll = 0;
	}
	
	public RotationMatrix(float yaw, float pitch, float roll) {
		super();
		
		this.yaw = yaw;
		this.pitch = pitch;
		this.roll = roll;
		
		updateMatrix();
	}
	
	public void setYawPitchRow(float yaw, float pitch, float roll) {
		this.yaw = yaw;
		this.pitch = pitch;
		this.roll = roll;
		
		updateMatrix();
	}
	
	public void setYaw(float yaw) {
		this.yaw = yaw;
		updateMatrix();
	}
	
	public void setPitch(float pitch) {
		this.pitch = pitch;
		updateMatrix();
	}
	
	public void setRoll(float roll) {
		this.roll = roll;
		updateMatrix();
	}
	
	public static Matrix4x4 createFromAxisAndAngle(Vector3D axis, float angle) {
		// Algorithm from http://www.euclideanspace.com/maths/geometry/rotations/conversions/angleToMatrix/index.htm,
		// page viewed on May 10, 2011.
	
		Matrix4x4 finalMatrix = new Matrix4x4();
		finalMatrix.identity();
		
		Vector3D normalizedAxis = axis.normalized();
		float cos = (float) Math.cos(angle);
		float sin = (float) Math.sin(angle);
		float t = 1 - cos;
		float x = normalizedAxis.x();
		float y = normalizedAxis.y();
		float z = normalizedAxis.z();
		
		finalMatrix.setElement(1, 1, t*x*x + cos);
		finalMatrix.setElement(1, 2, t*x*y - z*sin);
		finalMatrix.setElement(1, 3, t*x*z + y*sin);
		
		finalMatrix.setElement(2, 1, t*x*y + z*sin);
		finalMatrix.setElement(2, 2, t*y*y + cos);
		finalMatrix.setElement(2, 3, t*y*z - x*sin);
		
		finalMatrix.setElement(3, 1, t*x*z - y*sin);
		finalMatrix.setElement(3, 2, t*y*z + x*sin);
		finalMatrix.setElement(3, 3, t*z*z + cos);
		
		return finalMatrix;
	}
	
	private void updateMatrix() {
		
		Matrix4x4 yawMatrix = new Matrix4x4();
		Matrix4x4 pitchMatrix = new Matrix4x4();
		Matrix4x4 rollMatrix = new Matrix4x4();
		
		yawMatrix.setElement(1, 1, (float) Math.cos(this.yaw));
		yawMatrix.setElement(1, 2, (float) -Math.sin(this.yaw));
		yawMatrix.setElement(2, 1, (float) Math.sin(this.yaw));
		yawMatrix.setElement(2, 2, (float) Math.cos(this.yaw));
		
		pitchMatrix.setElement(1, 1, (float) Math.cos(this.pitch));
		pitchMatrix.setElement(1, 3, (float) Math.sin(this.pitch));
		pitchMatrix.setElement(3, 1, (float) -Math.sin(this.pitch));
		pitchMatrix.setElement(3, 3, (float) Math.cos(this.pitch));
		
		rollMatrix.setElement(2, 2, (float) Math.cos(this.roll));
		rollMatrix.setElement(2, 3, (float) -Math.sin(this.roll));
		rollMatrix.setElement(3, 2, (float) Math.sin(this.roll));
		rollMatrix.setElement(3, 3, (float) Math.cos(this.roll));

		identity();
		mult(rollMatrix);
		mult(pitchMatrix);
		mult(yawMatrix);
	}
}
