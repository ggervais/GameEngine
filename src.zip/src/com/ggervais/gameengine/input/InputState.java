package com.ggervais.gameengine.input;

public enum InputState {
	UP, DOWN
}
