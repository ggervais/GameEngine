package com.ggervais.gameengine.input;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import com.ggervais.gameengine.game.Game;

public class InputListener implements KeyListener, MouseListener, MouseMotionListener {
	
	private KeyboardState keyboardState;
	private MouseState mouseState;
	private int width;
	private int height;
	private Game game;
	
	private boolean registerMouseEvent;
	
	public InputListener(Game game) {
		this.keyboardState = new KeyboardState();
		this.mouseState = new MouseState();
		this.registerMouseEvent = true;
		this.game = game;
		this.width = game.getWidth();
		this.height = game.getHeight();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		this.keyboardState.pressKey(e.getKeyCode());
		this.game.update();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		this.keyboardState.releaseKey(e.getKeyCode());
		this.game.update();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			this.mouseState.setLeftButtonClicked(true);
		}
		if (e.getButton() == MouseEvent.BUTTON2) {
			this.mouseState.setMiddleButtonClicked(true);
		}
		if (e.getButton() == MouseEvent.BUTTON3) {
			this.mouseState.setRightButtonClicked(true);
		}
		this.game.update();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			this.mouseState.setLeftButtonClicked(false);
		}
		if (e.getButton() == MouseEvent.BUTTON2) {
			this.mouseState.setMiddleButtonClicked(false);
		}
		if (e.getButton() == MouseEvent.BUTTON3) {
			this.mouseState.setRightButtonClicked(false);
		}
		this.game.update();
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		this.mouseState.setMouseX(e.getX());
		this.mouseState.setMouseY(e.getY());
	}

	@Override
	public void mouseMoved(MouseEvent e) {

		int relativeX = e.getX();
		int relativeY = e.getY();
		int absoluteX = e.getXOnScreen();
		int absoluteY = e.getYOnScreen();
		
		int offsetX = absoluteX - relativeX;
		int offsetY = absoluteY - relativeY;

		this.mouseState.setMouseX(relativeX);
		this.mouseState.setMouseY(relativeY);

		this.game.getScene().getCamera().update(null);
		
		if (relativeX <= 15 || relativeY <= 15 || 
			relativeX >= this.width - 15 || relativeY >= this.height - 15) {
			int centerX = this.width / 2;
			int centerY = this.height / 2;
			
			this.registerMouseEvent = false;
			this.mouseState.setLastEventSource(EventSource.SYSTEM);
			try {
				Robot robot = new Robot();
				robot.mouseMove(offsetX + centerX, offsetY + centerY);
			} catch (AWTException ae) {}
		} else {
			this.mouseState.setLastEventSource(EventSource.USER);	
		}
	}
	
	public KeyboardState getCurrentKeyboardState() {
		KeyboardState current = null;
		try {
			current = this.keyboardState.clone();
		} catch (CloneNotSupportedException cnse) {
			current = this.keyboardState;
		}
		return current;
	}
	
	public MouseState getCurrentMouseState() {
		MouseState current = null;
		try {
			current = this.mouseState.clone();
		} catch (CloneNotSupportedException cnse) {
			current = this.mouseState;
		}
		return current;
	}
}
