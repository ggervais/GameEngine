package com.ggervais.gameengine.input;

public enum EventSource {
	USER, SYSTEM
}
