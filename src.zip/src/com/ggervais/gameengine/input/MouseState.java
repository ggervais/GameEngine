package com.ggervais.gameengine.input;

public class MouseState implements Cloneable {

	private int mouseX;
	private int mouseY;
	private boolean leftButtonClicked;
	private boolean middleButtonClicked;
	private boolean rightButtonClicked;
	private EventSource lastEventSource;

	public void setMouseX(int mouseX) {
		this.mouseX = mouseX;
	}
	public int getMouseX() {
		return mouseX;
	}
	public void setMouseY(int mouseY) {
		this.mouseY = mouseY;
	}
	public int getMouseY() {
		return mouseY;
	}
	public void setLeftButtonClicked(boolean leftButtonClicked) {
		this.leftButtonClicked = leftButtonClicked;
	}
	public boolean isLeftButtonClicked() {
		return leftButtonClicked;
	}
	public void setRightButtonClicked(boolean rightButtonClicked) {
		this.rightButtonClicked = rightButtonClicked;
	}
	public boolean isRightButtonClicked() {
		return rightButtonClicked;
	}
	public void setMiddleButtonClicked(boolean middleButtonClicked) {
		this.middleButtonClicked = middleButtonClicked;
	}
	public boolean isMiddleButtonClicked() {
		return middleButtonClicked;
	}

	@Override
	public MouseState clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return (MouseState) super.clone();
	}
	public void setLastEventSource(EventSource lastEventSource) {
		this.lastEventSource = lastEventSource;
	}
	public EventSource getLastEventSource() {
		return lastEventSource;
	}
	
}
