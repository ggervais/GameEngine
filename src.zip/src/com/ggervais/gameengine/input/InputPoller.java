package com.ggervais.gameengine.input;

import net.java.games.input.Component;
import net.java.games.input.Controller;
import net.java.games.input.ControllerEnvironment;
import net.java.games.input.Keyboard;
import net.java.games.input.Mouse;
import net.java.games.input.Component.Identifier.Key;

public class InputPoller {
	private Mouse mouse;
	private Keyboard keyboard;
	
	public InputPoller() {
		this.mouse = null;
		this.keyboard = null;
	}
	
	public void init() {
		ControllerEnvironment environment =	ControllerEnvironment.getDefaultEnvironment();
		for (Controller controller : environment.getControllers()) {
			if (controller.getType() == Controller.Type.MOUSE) {
				this.mouse = (Mouse) controller;
			}
			if (controller.getType() == Controller.Type.KEYBOARD) {
				this.keyboard = (Keyboard) controller;
			}
			if (mouse != null && keyboard != null) {
				break;
			}
		}
	}
	
	public boolean update() {
		boolean mousePolled = this.mouse.poll();
		boolean keyboardPolled = this.keyboard.poll();
		
		return mousePolled && keyboardPolled;
	}
	
	public float getMouseMovementX() {
		float movement = 0;
		Component mouseXAxis = this.mouse.getX();
		if (mouseXAxis.isRelative()) {
			movement = mouseXAxis.getPollData();
		}
		return movement;
	}
	
	public float getMouseMovementY() {
		float movement = 0;
		Component mouseYAxis = this.mouse.getY();
		if (mouseYAxis.isRelative()) {
			movement = mouseYAxis.getPollData();
		}
		return movement;
	}
	
	public boolean isKeyDown(Key key) {
		return this.keyboard.isKeyDown(key);
	}
}
