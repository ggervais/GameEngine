package com.ggervais.gameengine.input;

import java.util.HashMap;
import java.util.Map;

public class KeyboardState implements Cloneable {

	private HashMap<Integer, InputState> keys;
	private EventSource lastEventSource;
	
	public KeyboardState() {
		this.keys = new HashMap<Integer, InputState>();
	}
	
	public void pressKey(int key) {
		this.keys.put(new Integer(key), InputState.DOWN);
	}
	
	public void releaseKey(int key) {
		this.keys.put(new Integer(key), InputState.UP);
	}
	
	public boolean isKeyUp(int key) {
		InputState state = this.keys.get(new Integer(key));
		if (state == null) {
			return true;
		} else if (state == InputState.UP) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isKeyDown(int key) {
		InputState state = this.keys.get(new Integer(key));
		return state != null && state == InputState.DOWN;
	}
	
	public Map<Integer, InputState> keys() {
		return this.keys;
	}
	
	@Override
	public KeyboardState clone() throws CloneNotSupportedException {
		
		HashMap<Integer, InputState> keysClone = (HashMap<Integer, InputState>) this.keys.clone();
		KeyboardState clone = (KeyboardState) super.clone();
		clone.keys = keysClone;
		
		return clone;
	}

	public void setLastEventSource(EventSource lastEventSource) {
		this.lastEventSource = lastEventSource;
	}

	public EventSource getLastEventSource() {
		return lastEventSource;
	}
}
